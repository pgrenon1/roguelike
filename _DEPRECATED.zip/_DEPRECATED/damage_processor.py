from components import (
    Health,
    Damage,
    Death,
    Metadata
)
import engine
import esper


class DamageProcessor(esper.Processor):
    def __init__(self):
        super().__init__()

    def process(self):
        for ent, (dam, hp) in self.world.get_components(Damage, Health):
            hp.current_health -= dam.damage
            engine.WORLD.remove_component(ent, Damage)
            if (hp.current_health == 0):
                engine.WORLD.add_component(ent, Death())
